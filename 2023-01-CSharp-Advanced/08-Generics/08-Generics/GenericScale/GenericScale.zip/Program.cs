﻿namespace GenericScale
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var a = new EqualityScale<int>(2, 2);
            Console.WriteLine(a.AreEqual());
        }
    }
}