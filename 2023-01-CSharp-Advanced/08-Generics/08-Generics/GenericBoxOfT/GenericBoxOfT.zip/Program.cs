﻿using System;

namespace GenericBoxOfT;

internal class Program
{
    static void Main(string[] args)
    {
        int numberOfLine = int.Parse(Console.ReadLine());

        for (int i = 0; i < numberOfLine; i++)
        {
            Box<string> box = new Box<string>();
            box.Value = Console.ReadLine();
            Console.WriteLine(box.ToString());
        }
    }
}